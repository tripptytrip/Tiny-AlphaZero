"""Gradio dashboard for TinyAlphaZero."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import chess
import chess.svg
import gradio as gr
import torch

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.append(str(SRC))

from benchmarks import ChessBenchmarkRunner, default_benchmarks  # noqa: E402
from data.encoding import decode_move, encode_board  # noqa: E402
from model.transformer import ChessTransformer  # noqa: E402


def get_device(requested: str) -> torch.device:
    if requested == "cpu":
        return torch.device("cpu")
    if requested == "cuda":
        return torch.device("cuda")
    if requested == "mps":
        return torch.device("mps")
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _resolve_checkpoint(checkpoint: str) -> str:
    if not checkpoint:
        return checkpoint
    path = Path(checkpoint)
    if path.is_dir():
        candidates = sorted(path.glob("*.pt"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not candidates:
            raise FileNotFoundError(f"No .pt checkpoints found in {path}")
        return str(candidates[0])
    return checkpoint


def load_model(checkpoint: str, device: torch.device) -> ChessTransformer:
    model = ChessTransformer().to(device)
    if checkpoint:
        resolved = _resolve_checkpoint(checkpoint)
        payload = torch.load(resolved, map_location=device)
        model.load_state_dict(payload["model_state_dict"])
    model.eval()
    return model


def _ensure_cpu_fallback(err: RuntimeError) -> None:
    global MODEL, DEVICE
    if DEVICE.type == "cpu":
        raise err
    print(f"Device error on {DEVICE}, retrying on CPU: {err}")
    DEVICE = torch.device("cpu")
    MODEL = ChessTransformer().to(DEVICE)


def analyze_position(fen: str) -> tuple[str, str, list, str]:
    board = chess.Board(fen)
    svg = chess.svg.board(board=board)

    board_tensor = torch.tensor(encode_board(board), dtype=torch.long, device=DEVICE)
    try:
        with torch.no_grad():
            policy_probs, value = MODEL.predict(board_tensor)
    except RuntimeError as err:
        _ensure_cpu_fallback(err)
        board_tensor = torch.tensor(encode_board(board), dtype=torch.long, device=DEVICE)
        with torch.no_grad():
            policy_probs, value = MODEL.predict(board_tensor)

    policy_probs = policy_probs.squeeze(0)
    legal_indices = [move for move in board.legal_moves]
    move_scores = []
    for move in legal_indices:
        idx = move.from_square * 64 + move.to_square
        move_scores.append((move.uci(), float(policy_probs[idx])))

    move_scores.sort(key=lambda x: x[1], reverse=True)
    top_moves = move_scores[:5]

    value_str = f"Value: {float(value):.3f}"
    return svg, value_str, top_moves, "Analysis complete"


def run_benchmarks() -> str:
    runner = ChessBenchmarkRunner(MODEL, device=DEVICE)
    try:
        results = runner.run(default_benchmarks())
    except RuntimeError as err:
        _ensure_cpu_fallback(err)
        runner = ChessBenchmarkRunner(MODEL, device=DEVICE)
        results = runner.run(default_benchmarks())

    lines = []
    for result in results:
        status = "PASS" if result["passed"] else "FAIL"
        lines.append(f"{result['name']}: {status} (legal mass {result['legal_move_mass']:.4f})")
        for check_name, passed in result["checks"]:
            lines.append(f"  {check_name}: {'ok' if passed else 'fail'}")

    return "\n".join(lines)


def build_ui() -> gr.Blocks:
    with gr.Blocks() as demo:
        gr.Markdown("# TinyAlphaZero Dashboard")

        with gr.Tabs():
            with gr.TabItem("Position Analyzer"):
                fen_input = gr.Textbox(value=chess.STARTING_FEN, label="FEN")
                analyze_btn = gr.Button("Analyze")
                board_svg = gr.HTML()
                value_out = gr.Textbox(label="Value")
                top_moves = gr.Dataframe(headers=["Move", "Prob"], datatype=["str", "number"])
                status = gr.Textbox(label="Status")

                analyze_btn.click(
                    analyze_position, inputs=[fen_input], outputs=[board_svg, value_out, top_moves, status]
                )

            with gr.TabItem("Benchmarks"):
                bench_btn = gr.Button("Run Benchmarks")
                bench_out = gr.Textbox(lines=10, label="Results")
                bench_btn.click(run_benchmarks, outputs=[bench_out])

    return demo


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="")
    parser.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda", "mps"])
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()

    global MODEL, DEVICE
    DEVICE = get_device(args.device)
    try:
        MODEL = load_model(args.checkpoint, DEVICE)
    except RuntimeError as err:
        _ensure_cpu_fallback(err)

    ui = build_ui()
    ui.launch(server_name=args.host, server_port=args.port)


if __name__ == "__main__":
    main()
